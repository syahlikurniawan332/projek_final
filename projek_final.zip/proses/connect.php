<?php
$conn = mysqli_connect("localhost","root", "", "db_gudangudetiara");
if(!$conn){
    echo "gagal koneksi";
}
?>